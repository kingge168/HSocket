﻿var net = require('net');
var unit = function () {
    var port = 8251;
    var host = '127.0.0.1';
    var client = new net.Socket();
    client.setEncoding('utf-8');
    client.connect(port, host, function () {
        client.write('0000000009Test abcd');
        client.on('data', function (data) {
            //console.log('recv:' + data);
            client.end();
        });
    });
    client.on('error', function (error) {
        console.error(error);
        client.end();
    });
    client.on('close', function () {
        //console.log('connection closed');
    });
}
function Loop(count) {
    for (var i = 0; i < count; i++) {
        unit();
    }
}
function Timer(time) {
    var callee = arguments.callee;
    var timeout=setTimeout(function () { Loop(100); clearTimeout(timeout); callee(time); },time);
}
//console.time('test');
Timer(25);
//console.timeEnd('test');
//Loop(1000);
//setTimeout(function () { },1000000);